﻿Public Class Form13
    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Form13_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class