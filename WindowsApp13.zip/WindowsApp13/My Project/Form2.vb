﻿Public Class Form2
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If TextBox1.Text = "" And TextBox2.Text = "" Then
            MessageBox.Show("Login Successfully")
            Form4.Show()
        ElseIf TextBox1.Text = "Admin" And TextBox2.Text = "143" Then
            Form5.Show()
        Else
            MessageBox.Show("Username or Password is incorrect, Please Check")
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnClick_Click(sender As Object, e As EventArgs) Handles btnClick.Click
        Form3.Show()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            TextBox2.PasswordChar = "*"
        Else
            TextBox2.PasswordChar = ""
        End If
    End Sub
End Class
